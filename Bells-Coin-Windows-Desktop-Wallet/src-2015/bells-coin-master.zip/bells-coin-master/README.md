Bells [BEL]
================================

http://www.bellscoin.org

Copyright (c) 2009-2015 Bitcoin Developers
Copyright (c) 2011-2015 Bells Developers

What is Bells?
----------------

Bells is an alternative cryptocurrency derived from Litecoin using scrypt as a proof-of-work algorithm.
 - 2.5 minute block targets
 - 500 million total coins
 - Retargeting every block through Digibyte's Digishield
 - RPC 19918
 - P2P 19919

Block rewards
----------------
 - 50% chance of 50 coins
 - 20% chance of 100 coins
 - 14% chance of 250 coins
 - 10% chance of 500 coins
 - 5% chance of 1000 coins
 - 1% chance of 10000 coins

Halving at 129600 (~90 days)
Decreasing by 4/5ths at 259200 blocks (~180 days)
After block 518,400 (~1 year), reward of 2 coins. 

More information
-------
For more information, as well as an immediately useable, binary version of
the Bells client sofware, see http://www.bellscoin.org.

License
-------

Bells is released under the terms of the MIT license. See `COPYING` for more
information or see http://opensource.org/licenses/MIT.

